# Tax-Calculator-JavaScript
A JavaScript built Income Tax Calculator giving full tax breakdown information dependant on salary and tax bands.
